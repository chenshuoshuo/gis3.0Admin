// CMCCR CMIPS CMDBE配置项
window.g = {
  // 中控发布平台接口地址
  // BASE_CCR: 'https://cmdown.parkbobo.com/cmccr-server',
  BASE_CCR: 'http://192.168.4.241/cmccr-server',
  // 地图门户管理接口地址
  // BASE_IPS: 'https://cmdown.parkbobo.com/cmips-server',
  BASE_IPS: 'http://192.168.4.241/cmips-server',
  // CMGIS 接口地址
  // BASE_GIS: 'https://cmdown.parkbobo.com/cmgis-server'
  BASE_GIS: 'http://192.168.4.241/cmgis-server'
}
// 地图token
if (window.creeper) { window.creeper.CreeperConfig.token = 'anNfc2RrOmZjM2Q0MDBmOTM2NDE5YTgxNTE4NjIyYWQyZmIxZTAz' }

