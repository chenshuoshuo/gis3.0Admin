//CMCCR CMIPS CMDBE配置项
window.g = {
  // 中控发布平台接口地址
  BASE_CCR: 'http://192.168.4.241:8100/cmccr',
  // 地图门户管理接口地址
  BASE_IPS: 'http://192.168.4.241:6062',
  //CMGIS 接口地址
  BASE_GIS: 'http://192.168.4.241:5049/gis'
}

// 地图token
if(window.creeper)
	window.creeper.CreeperConfig.token = 'cWluY2hlbmdqaWU6MTIzNDU2'

